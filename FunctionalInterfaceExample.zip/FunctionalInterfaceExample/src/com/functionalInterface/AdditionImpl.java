package com.functionalInterface;

public class AdditionImpl implements Addition {

	public void add() {
		System.out.println("Hi");
	}

}
