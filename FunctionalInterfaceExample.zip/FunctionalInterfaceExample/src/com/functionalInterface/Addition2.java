package com.functionalInterface;
/*
@FunctionalInterface
public interface Addition2 extends Addition {
	public void sum();
}
*/