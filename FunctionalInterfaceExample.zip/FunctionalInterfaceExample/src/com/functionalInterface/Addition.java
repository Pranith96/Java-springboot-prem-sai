package com.functionalInterface;

@FunctionalInterface
public interface Addition {
	public void add();
}
